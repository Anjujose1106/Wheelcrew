<!DOCTYPE html>
<html>
<head>
 <title>USERS LIST</title>
 <style type="text/css">
  body{
	margin:0;
	padding:0;
	background:url(images_staff/111.jpg);
    background-repeat: no-repeat;
    background-position: center;
    background-attachment: fixed;
    background-size: cover;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    -ms-background-size: cover;
	 font-family: 'Roboto', sans-serif;
 }
  #lab{
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
 }
 #lab td, #lab th {
  border: 1px solid #ddd;
  padding: 8px;
}

#lab tr:nth-child(even){background-color: #f2f2f2;}

#lab tr:hover {background-color: #ddd;}

#lab th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
 </style>
</head>
<body>
<table id="lab">
 <tr>
   <th>Name</th>
   <th>Payment_id</th>
   <th>Address </th>
   
   </tr>
   <?php


$link=mysqli_connect("localhost","root","","wheelcrew");
if($link===false)
{
	echo "Sorry Connection Lost";

}
else
{

$sql = "SELECT name,address,mobile FROM login";
$result=$link->query($sql);

if($result -> num_rows > 0)
{
    while($row = $result->fetch_assoc())
    {
        echo "<tr><td>". $row["full_name"] ."</td><td>". $row["1"]."</td><td>". $row["address"]."</td></tr>";
    }
    echo "</table>";
}
else {
    echo "No result";
}

$link->close(); 
}
?>
</table>
</body>
</html>






<!DOCTYPE html>
<html lang="en">
<head>
<title>Update Vehicle</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Auditions Registration Form Widget Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>

<link href="css_sign/style.css" rel="stylesheet" type="text/css" media="all" />

<script type="text/javascript" src="js1/jquery-2.1.4.min.js"></script>

</head>
<body>
<!--
<script type="text/javascript">
function val(){
if(addcoor.mobile.value=="")
{
	alert("Please enter the mobile number");
	addcoor.mobile.focus(); 
	return false;
}
if(isNaN(addcoor.mobile.value))
{
	alert("Invalid mobile number");
	addcoor.mobile.focus(); 
	return false;
}
if((addcoor.mobile.value).length < 10)
{
	alert("Mobile number should be minimum 10 digits");
	addcoor.mobile.focus(); 
	return false;
}

if(addcoor.department.value=="none")
	{
		alert("Please select Department.");
		addcoor.department.focus(); 
		return false;
	}
	
	if(addcoor.type.value=="none")
	{
		alert("Please select Co-ordinator Type.");
		addcoor.type.focus(); 
		return false;
	}

return true;
}


</script>
-->



<form name="addcoor" autocomplete="off" action="updateveh.php" method="post">


	<div class="center-container">
	<div class="banner-dott">
		<div class="main">
			<h1 class="w3layouts_head">Stock Update</h1>
				<div class="w3layouts_main_grid">
				
						
					
					<div class="w3_agileits_main_grid w3l_main_grid">
							<span class="agileits_grid">
								<label>Vehicle Name </label><br><br>
								<input type="text" style="width:85%" name="vehname" placeholder="Name" required="">
							</span>
						</div>


						<div class="w3_agileits_main_grid w3l_main_grid">
							<span class="agileits_grid">
								<label>Register Number</label><br><br>
								<input type="text" style="width:85%" name="regno" placeholder="Register Number" required="">
							</span>
						</div>


					

						


						
						
											
					<div class="w3_main_grid">
                    
						<div class="w3_main_grid_right">
							<center>
                            <input type="submit" value="Submit">
						</center>
                      
                        </div>
					</div>


					<div class="w3_main_grid">
                    
						<div class="w3_main_grid_right">
					<!--	<center>
							<label><font color="white">Already have an Account?</font></label> &nbsp &nbsp
							<a href="../Login_Page/index.php">
								<input type="button" style="top:-5%"value="LOGIN">
</a>
						</center> -->
						
                      
						</div>
						
					</div>
				
			</div>
		
		</div>
        </div>
        </div>

</form>

</body>
</html>
<?php

$link=mysqli_connect("localhost","root","","wheelcrew");
if($link===false)
{
	echo "Sorry Connection Lost";

}
else
{

    $sql="Select name,address,mobile from login";





}
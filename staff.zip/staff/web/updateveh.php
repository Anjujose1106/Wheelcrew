

<?php
$link=mysqli_connect("localhost","root","","wheelcrew");
if($link===false)
		{
			echo "Sorry Connection Lost";

		}
else
		{
			
		$name=$_POST['vehname'];
		$reg=$_POST['regno'];
	

		
		
		
		
			 $sql = "INSERT INTO rent_veh(vehname,regno) VALUES ('$name','$reg')";

		if(mysqli_query($link, $sql))
			{
						echo '<script type="text/javascript">'; 
						echo 'alert("vehicle added ");'; 
						echo 'window.history.back();';
						echo '</script>';
			} 

		

		

			
			
		}
?>
